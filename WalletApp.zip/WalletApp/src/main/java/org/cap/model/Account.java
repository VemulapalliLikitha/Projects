package org.cap.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class Account {
	@Id
private int accId;
private int accNumber;
private String accType;
private double openingBal;
private Date openingDate;
@OneToMany(mappedBy="transId")
private Transaction transaction;
public Account() {
	
}

public Account(int accId, int accNumber, String accType, double openingBal, Date openingDate) {
	super();
	this.accId = accId;
	this.accNumber = accNumber;
	this.accType = accType;
	this.openingBal = openingBal;
	this.openingDate = openingDate;
}

public int getAccId() {
	return accId;
}
public void setAccId(int accId) {
	this.accId = accId;
}
public int getAccNumber() {
	return accNumber;
}
public void setAccNumber(int accNumber) {
	this.accNumber = accNumber;
}
public String getAccType() {
	return accType;
}
public void setAccType(String accType) {
	this.accType = accType;
}
public double getOpeningBal() {
	return openingBal;
}
public void setOpeningBal(double openingBal) {
	this.openingBal = openingBal;
}
public Date getOpeningDate() {
	return openingDate;
}
public void setOpeningDate(Date openingDate) {
	this.openingDate = openingDate;
}
@Override
public String toString() {
	return "Account [accId=" + accId + ", accNumber=" + accNumber + ", accType=" + accType + ", openingBal="
			+ openingBal + ", openingDate=" + openingDate +  "]";
}


}
