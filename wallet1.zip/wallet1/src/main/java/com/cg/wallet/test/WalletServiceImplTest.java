package com.cg.wallet.test;

import com.cg.wallet.bean.Wallet;
import com.cg.wallet.dao.WalletDaoImpl;
import com.cg.wallet.exception.WalletException;
import com.cg.wallet.service.WalletServiceImpl;

import junit.framework.Assert;
import junit.framework.TestCase;

public class WalletServiceImplTest extends TestCase {


	public void testValidateNamefail() {
		WalletServiceImpl c=new WalletServiceImpl();
		try {
			Assert.assertEquals(false, c.validateName("Liki@"));
		}
		catch(WalletException e ) {
			
		}
	}

	public void testValidatePhonefail() {
		WalletServiceImpl t=new WalletServiceImpl();
		try {
			Assert.assertEquals(false, t.validatePhone("98765432176"));
		}
		catch(WalletException e ) {
			
		}
	}
	public void testValidateName() {
		WalletServiceImpl c=new WalletServiceImpl();
		try {
			Assert.assertEquals(true, c.validateName("Liki"));
		}
		catch(WalletException e ) {
			
		}
	}
	
	public void testValidatePhone() {
		WalletServiceImpl t=new WalletServiceImpl();
		try {
			Assert.assertEquals(true, t.validatePhone("9876543217"));
		}
		catch(WalletException e ) {
			
		}
	}

	public void testCreateAccount() {
		WalletDaoImpl w=new WalletDaoImpl();
		Wallet a=new Wallet();
		Assert.assertEquals(5001, 5001);
	}

	

}
