package org.cap.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Transaction {
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private int transId;
private Date transDate;
private String transType;
private int fromAccno;
private int toAccno;
private double amt;
private String description;
private String stat;


public Transaction() {
	
}
public Transaction(int transId, Date transDate, String transType, int fromAccno, int toAccno, double amt,
		String description, String stat) {
	super();
	this.transId = transId;
	this.transDate = transDate;
	this.transType = transType;
	this.fromAccno = fromAccno;
	this.toAccno = toAccno;
	this.amt = amt;
	this.description = description;
	this.stat = stat;
}
public int getTransId() {
	return transId;
}
public void setTransId(int transId) {
	this.transId = transId;
}
public Date getTransDate() {
	return transDate;
}
public void setTransDate(Date transDate) {
	this.transDate = transDate;
}
public String getTransType() {
	return transType;
}
public void setTransType(String transType) {
	this.transType = transType;
}
public int getFromAccno() {
	return fromAccno;
}
public void setFromAccno(int fromAccno) {
	this.fromAccno = fromAccno;
}
public int getToAccno() {
	return toAccno;
}
public void setToAccno(int toAccno) {
	this.toAccno = toAccno;
}
public double getAmt() {
	return amt;
}
public void setAmt(double amt) {
	this.amt = amt;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public String getStat() {
	return stat;
}
public void setStat(String stat) {
	this.stat = stat;
}
@Override
public String toString() {
	return "Transaction [transId=" + transId + ", transDate=" + transDate + ", transType=" + transType + ", fromAccno="
			+ fromAccno + ", toAccno=" + toAccno + ", amt=" + amt + ", description=" + description + ", stat=" + stat
			+ "]";
}

}
