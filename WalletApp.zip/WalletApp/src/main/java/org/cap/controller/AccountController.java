package org.cap.controller;

import java.util.List;


import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AccountController {

	@PostMapping("/validateLogin")
	public String validateLogin(ModelMap map, 
			@RequestParam("userName")String userName,
			@RequestParam("userPwd")String userPwd) {
		
		
		if(userName.equals("likitha") && 
				userPwd.equals("likitha123")) {
			
			return "main";
		}
		
		return "redirect:/";
	}
	
	
	
	
	
	
	
	@RequestMapping("/createAccount")
	public String showCreateAccountPage() {
		return "createAccount";
	}
	

	@RequestMapping("/showBalance")
	public String showBalancePage() {
		return "showBalance";
	}
	

	@RequestMapping("/Deposit")
	public String showDepositPage() {
		return "Deposit";
	}
	

	@RequestMapping("/Withdraw")
	public String showWithdrawPage() {
		return "Withdraw";
	}
	

	@RequestMapping("/fundTransfer")
	public String showfundTransferPage() {
		return "fundTransfer";
	}

	@RequestMapping("/printTransactions")
	public String showprintTransactionsPage() {
		return "printTransactions";
	}
}
