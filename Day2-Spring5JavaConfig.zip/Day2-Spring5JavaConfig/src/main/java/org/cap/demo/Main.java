package org.cap.demo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

public class Main {

	public static void main(String[] args) {
	AbstractApplicationContext context = new AnnotationConfigApplicationContext(JavaConfig.class);
				
				Employee employee = context.getBean(Employee.class);
				Address address=context.getBean(Address.class);
				System.out.println(employee);
				
				Student student=context.getBean(Student.class);
				System.out.println(student);
			}
			

	}


