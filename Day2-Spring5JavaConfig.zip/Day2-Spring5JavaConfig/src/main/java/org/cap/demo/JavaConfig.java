package org.cap.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
@Import({Myconfig.class})
@Configuration
public class JavaConfig {


	@Bean
	public Employee getEmployeebean() {
		Employee employee=new Employee();
		employee.setAge(21);
		employee.setEmployeeid(1);
		employee.setSalary(50000.00);
		employee.setEmployeename("Likitha");
		
		return employee;
		
	}
	@Bean
	public Address getAddress() {
		Address address=new Address();
		address.setCity("Hyderabad");
		address.setDoorNo("21");
		address.setStName("Aditya Nagar");
		
		return address;
		
	}
}

