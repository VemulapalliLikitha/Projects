package org.capstore.user.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {

	@RequestMapping("/ChangePassword")
	public String changePassword(ModelMap map) {
		
		
		return "ChangePassword";
		
	}
	
}
