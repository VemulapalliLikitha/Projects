package password;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import page.ChangePasswordBean;

public class Stepdef {
	private WebDriver driver;
	
	private ChangePasswordBean changepasswordBean;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\chromedriver.exe");
		 driver=new ChromeDriver();
		 //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 changepasswordBean =new ChangePasswordBean(driver);
		
	}
	@Given("^Change Password Page$")
	public void change_Password_Page() throws Throwable {
	    driver.get("http://localhost:8085/capstore/");
	}

	@When("^user enters the old password$")
	public void user_enters_the_old_password() throws Throwable {
		changepasswordBean.setPassword1("likitha");
	   
	}

	@When("^enters the new password$")
	public void enters_the_new_password() throws Throwable {
	   changepasswordBean.setPassword2("pinky");
	}

	@When("^confirms the new password$")
	public void confirms_the_new_password() throws Throwable {
		changepasswordBean.setPassword3("pinky");
	  
	}

	@When("^clicks change password$")
	public void clicks_change_password() throws Throwable {
		changepasswordBean.setSubmit();
	    
	}

	@Then("^display password changed succesfully$")
	public void display_password_changed_succesfully() throws Throwable {
	    
	}

	@When("^user clicks change password without entering password$")
	public void user_clicks_change_password_without_entering_password() throws Throwable {
	   
	}

	@Then("^display error message$")
	public void display_error_message() throws Throwable {
	   
	}

	@When("^if  they match$")
	public void if_they_match() throws Throwable {
	    
	}

	@When("^if it doesnt match with database$")
	public void if_it_doesnt_match_with_database() throws Throwable {
	   
	}

	@When("^user enters the new password$")
	public void user_enters_the_new_password() throws Throwable {
	   
	}

	@When("^enters the confirm password$")
	public void enters_the_confirm_password() throws Throwable {
	    
	}

	@When("^if they dont match$")
	public void if_they_dont_match() throws Throwable {
	   
	}

	@When("^the new password doesnt meet the constraints$")
	public void the_new_password_doesnt_meet_the_constraints() throws Throwable {
	  
	}
}
