package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ChangePasswordBean {
WebDriver driver;
@FindBy(name="password1")
private WebElement password1;
@FindBy(name="password2")
private WebElement password2;
@FindBy(name="password3")
private WebElement password3;
@FindBy(name="submit")
private WebElement submit;

public ChangePasswordBean(WebDriver driver) {
	 this.driver=driver;
	 PageFactory.initElements(driver, this);
}
public void setPassword1(String old)
{
	password1.sendKeys(old);
}

public void setPassword2(String npwd)
{
	password2.sendKeys(npwd);
}

public void setPassword3(String cnpwd)
{
	password3.sendKeys(cnpwd);
}


public void setSubmit()
{
	submit.click();
}
}
