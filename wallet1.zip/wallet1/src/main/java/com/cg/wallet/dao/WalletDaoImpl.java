package com.cg.wallet.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import com.cg.wallet.bean.Customer;
import com.cg.wallet.bean.Transactions;
import com.cg.wallet.bean.Wallet;
import com.cg.wallet.exception.WalletException;

public class WalletDaoImpl implements WalletDao{
	static HashMap<Integer,Customer> custmap=new HashMap<Integer,Customer>();
	static HashMap<Integer,Wallet> walletmap=new HashMap<Integer,Wallet>();
	static Map<String,Transactions> transactions=new HashMap<String,Transactions>();
	static Transactions transaction=new Transactions();
	
	public int createAccount(Customer customer) throws WalletException {

	try {
			if(custmap.size()==0)
			{
				customer.setId(1001);
			}
			else {
				Optional<Integer> id=custmap.keySet().stream().max((x,y)->x>y?1:x<y?-1:0);
				int custid=id.get()+1;
				customer.setId(custid);
			}
			custmap.put(customer.getId(), customer);
			return customer.getId();
			
		}
		catch(Exception ex)
		{
			throw new WalletException(ex.getMessage());
		}
	}

	
	public int assignAccount(String type) throws WalletException {
		Wallet wallet=new Wallet();
		double balanceamount=0;

		try {
			if(walletmap.size()==0)
			{
				wallet.setAccountno(5001);
				wallet.setBalance(balanceamount);
			}
			else {
				Optional <Integer> account=walletmap.keySet().stream().max((x,y)->x>y?1:x<y?-1:0);
				int accno=account.get()+1;
				wallet.setAccountno(accno);
				wallet.setBalance(balanceamount);
			}
			
			walletmap.put(wallet.getAccountno(), wallet);
			//return wallet.getAccountno();

		}
		catch(Exception ex)
		{
			throw new WalletException(ex.getMessage());
		}
		return wallet.getAccountno();
	}

	
	public double showBalance(int accno) throws WalletException {

		Wallet value=new Wallet();
		double balance=0;
	
		try {
			
			if(!walletmap.containsKey(accno))
			{
				throw new WalletException("Invalid Account number..!");
			}
			else {
					value=walletmap.get(accno);
					balance=value.getBalance();
					//value.setBalance(balance);
					
				}
			 
		}
		catch(Exception ex)
		{
			System.out.println("Error occured:"+ex.getMessage());
		}
		return balance;
	}

	
	public double deposit(int accno, double amount) throws WalletException {

		Wallet value=new Wallet();
		double famount=0;
		try {
			if(!walletmap.containsKey(accno))
			{
				throw new WalletException("Invalid Account number..!");
			}
			else {
					value=walletmap.get(accno);
					famount=value.getBalance()+amount;
					value.setBalance(famount);
					
					
					Transactions transaction=new Transactions();
					
					String accnostr=String.valueOf(accno);
					transaction.setAccno(accnostr);
					transaction.setAmount(amount);
					transaction.setBalance(famount);
                    transaction.setTransactiontype("Deposit");
                    transactions.put(accnostr, transaction);
			}

		}
		catch(Exception ex)
		{
			System.out.println("Error occured:"+ex.getMessage());
		}
		return famount;
	}

	
	public int withdraw(int accno, double amount) throws WalletException {
		Wallet value=new Wallet();
		double famount=0;
		int status=0;
		try {
			if(!walletmap.containsKey(accno))
			{
				throw new WalletException("Invalid Account number..!");
			}
			else {
					value=walletmap.get(accno);
					famount=value.getBalance()-amount;
					value.setBalance(famount);
					
					
					Transactions transaction=new Transactions();
					
					String accnostr=String.valueOf(accno);
					transaction.setAccno(accnostr);
					transaction.setAmount(amount);
					transaction.setBalance(famount);
                    transaction.setTransactiontype("Withdraw");
                    transactions.put(accnostr, transaction);
					
					
					status=1;
				}

		}
		catch(Exception ex)
		{
			System.out.println("Error occured:"+ex.getMessage());
		}
		return status;
	}

	
	public int fundTransfer(int faccno, int taccno, double amount) throws WalletException {
		
		Wallet value1=new Wallet();	
		Wallet value2=new Wallet();

		
		double fromfinalamount=0;
		double tofinalamount=0;
		int status=0;
	
		try {
			if(!walletmap.containsKey(faccno)&&!walletmap.containsKey(taccno))
			{
				throw new WalletException("Invalid Account number..!");
			}
			else {
					value1=walletmap.get(faccno);
					value2=walletmap.get(taccno);

					fromfinalamount=value1.getBalance()-amount;
					value1.setBalance(fromfinalamount);
					tofinalamount=value2.getBalance()+amount;
					value2.setBalance(tofinalamount);
					
					
					
					Transactions transaction1=new Transactions();
					
					String faccnostr=String.valueOf(faccno);
					transaction1.setAccno(faccnostr);
					transaction1.setAmount(amount);
					transaction1.setBalance(fromfinalamount);
                    transaction1.setTransactiontype("Debited");
                    transactions.put(faccnostr, transaction1);
                    
                    
					Transactions transaction2=new Transactions();
					
					String taccnostr=String.valueOf(taccno);
					transaction2.setAccno(taccnostr);
					transaction2.setAmount(amount);
					transaction2.setBalance(tofinalamount);
                    transaction2.setTransactiontype("Credited");
                    transactions.put(taccnostr, transaction2);
					
					status=1;
				}

		}
		catch(Exception ex)
		{
			System.out.println("Error occured:"+ex.getMessage());
		}
		return status;
	
	}


	
	public Transactions printTransactions(String accno) throws WalletException {
		try {
			Map<String,Transactions> transactionmap=new HashMap<String,Transactions>();
			Transactions transaction=transactions.get(accno);
			if(transaction==null) {
				throw new WalletException("Customer with account number"+accno+"not available");
			}
			/*else
			{
				System.out.println("Success");
			}*/
			return transaction;
		}
		catch(Exception ex) {
			throw new WalletException(ex.getMessage());
		}
/*		return transaction;
*/		
		
	}
}
