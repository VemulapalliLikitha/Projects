package org.cap.exception;

public class InvalidBalance extends Exception {
	public  InvalidBalance(String msg) {
		super(msg);
	}
}
