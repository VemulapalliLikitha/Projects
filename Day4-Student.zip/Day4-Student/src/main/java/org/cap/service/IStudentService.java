package org.cap.service;

import java.util.List;

import org.cap.model.Student;

public interface IStudentService {
	 List<Student> getStudents();

	public Student findstudent(Integer studId);
	public void update(Student student);

	
}
