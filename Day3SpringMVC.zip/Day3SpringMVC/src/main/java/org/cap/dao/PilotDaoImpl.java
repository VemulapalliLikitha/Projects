package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
@Repository("pilotDao")

public class PilotDaoImpl implements PilotDao {
@PersistenceContext
private EntityManager entitymanager;
private Pilot pilot;
@Transactional
@Override
	public void save(Pilot pilot) {
		
		entitymanager.persist(pilot);
	}
@Transactional(readOnly=true)
	@Override
	public List<Pilot> getAll() {
		List<Pilot> pilots=(List<Pilot>) entitymanager.createQuery("from Pilot").getResultList();
		return pilots;
	}
@Transactional
@Override
public void delete(Integer pilotId) {
	Pilot pilot=entitymanager.find(Pilot.class, pilotId);
	entitymanager.remove(pilot);
	
}
@Transactional
@Override
public void update(Pilot pilot) {
	
	if(pilot.getPilotId()!=0)
		entitymanager.merge(pilot);
	else
		
		entitymanager.persist(pilot);
	
}
@Transactional
@Override
public Pilot findpilot(Integer pilotId) {
	Pilot pilot=entitymanager.find(Pilot.class, pilotId);
	return pilot;
}

}
