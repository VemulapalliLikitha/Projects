package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.model.Student;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
@Repository("studentDao")
public class StudentDaoImpl implements IStudentdao {
	@PersistenceContext
	private EntityManager entitymanager;
	@Transactional(readOnly=true)
	public List<Student> getStudents() {
		List<Student> students=(List<Student>) entitymanager.createQuery("from Student").getResultList();
		return students;
		
	}
	@Override
	public Student findstudent(Integer studId) {
		Student student=entitymanager.find(Student.class,studId);
		return student;
	}
	@Transactional
	@Override
	public void update(Student student) {
		if(student.getStudId()!=0)
			entitymanager.merge(student);
		else
			entitymanager.persist(student);
	}

}
